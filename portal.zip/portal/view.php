<?php 

session_start();

include ('config.php'); 
include "header.php"; 

 




// Check, if username session is NOT set then this page will jump to login page


?>

<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link href="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </head>
<body>
 


	 <div id="wrapper">

    
    

        <div id="page-wrapper">

            <div class="container">

                
                <div class="row">
                    <div class="col-lg-12" style="padding-left:167px;">

                        
                        <h1 class="page-header" style="margin-top: 100px;">
                            All Users
                        </h1>



    <table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>ProjectName</th>
             <th>Description</th>
            <th>Contact</th>
                        <th>URL</th>
            
        </tr>
    </thead>

    <tbody>
        
       
  <?php      
        if (isset($_SESSION['Email'])) {
	$Email = $_SESSION['Email'];
	$query = "SELECT * FROM projdetail" ; 
	$result= mysqli_query($connection , $query) or die (mysqli_error($connection));
	if (mysqli_num_rows($result) > 0 ) {
		$row = mysqli_fetch_array($result);
		 $id = $row['id'];
                $Name = $row['Name'];
                $Email = $row['Email'];
                $Department = $row['Department'];
                $Contact = $row['Contact'];
                $ProjectName = $row['ProjectName'];
                $Description = $row['Description'];
                $URL = $row['URL'];

                echo "<tr>";
                echo "<td>$id</td>";
               
                echo "<td>$Name</td>";
                echo "<td>$Email</td>";
                
                echo "<td>$Department</td>";
                 echo "<td>$ProjectName</td>";
                echo "<td>$Description</td>";
                echo "<td>$Contact</td>";
               
                echo "<td>$URL</td>";
               
                echo "</tr>";
             }
	}
?>

    </tbody>
 </table>


    

    </div>
    </div>
    </div>
    </div>

    </div>
    <script src="js/jquery.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>