<?php

include "config.php";
session_start();


if (isset($_POST['submit'])) {
     $Name=$_POST['Name'];
             $Email=$_POST['Email'];
             $Department=$_POST['Department'];
            $Contact=$_POST['Contact'];
             $ProjectName=$_POST['ProjectName'];
             $Description=$_POST['Description'];
    $URL=$_POST['URL'];
           
   
            $query=mysqli_query($connection,"INSERT INTO projdetail (Name,Email,Department,Contact,ProjectName,Description,URL) VALUES ('$Name',' $Email','$Department','$Contact','$ProjectName','$Description','$URL')");
                 echo "<script>window.location='view.php';</script>";
               
        /* if($query)
                {
                    echo "<script>window.location='index.php';</script>";
                }
            else
                {
                    die("error");
                }*/
  echo $_SESSION['Email']=$Email;
    
   if(!isset($_SESSION['Email']))
{
    echo "<script>window.location='login.php';</script>";
}
}
?>
 
    
    
    
    


<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="mainform.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="container">
<div class="jumbotron" style="text-align: center; font-size: 40px;">Project Details</div>
</div>


<div class="container">
    <div class="row">
        <div class="form_bg">
            <form method="post">
                 
                <br/>
                <div class="form-group">
                    <input type="name" name="Name" class="form-control" id="userid" placeholder="Name" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input type="email" name="Email" class="form-control" id="pwd" placeholder="Email" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input type="text" name="Department" class="form-control" id="userid" placeholder="Department"  autocomplete="off" required>
                </div>
                <div class="form-group">
                    <input type="tel" name="Contact" class="form-control" id="userid" autocomplete="off" pattern="[789][0-9]{9}" placeholder="Contact" required>
                </div>
                <div class="form-group">
                    <input type="ProjectName" name="ProjectName" class="form-control" id="pwd" autocomplete="off" placeholder="ProjectName" required>
                </div>
                
                <div class="form-group">
                    <textarea type="text" name="Description" class="form-control" id="pwd" autocomplete="off" placeholder="Description" required></textarea>
                </div>
                <div class="form-group">
                      <input type="url" name="URL" class="form-control" placeholder="Enter Website" autocomplete="off" required>  
                </div>
                <br/>
                <div class="align-center">
                    <button type="submit" name="submit" class="btn btn-default" id="login">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>