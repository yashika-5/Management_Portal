<?php
include 'config.php';
session_start();
unset($_SESSION['Email']);
session_destroy();
echo "<script>window.location='login.php';</script>";
?>