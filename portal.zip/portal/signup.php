<?php

include "config.php";


if (isset($_POST['submit'])) {
     $Name=trim($_POST['Name']);
     $Password=trim($_POST['Password']);
    $Confirm=trim($_POST['Confirm']);
    $Email=trim($_POST['Email']);
     $Contact=trim($_POST['Contact']);
    $Nationality=$_POST['Nationality'];
             
            
            $query=mysqli_query($connection,"INSERT INTO signup (Name,Password,Confirm,Email,Contact,Nationality) VALUES ('$Name','  $Password',' $Confirm','$Email',' $Contact','$Nationality');");
           $query1 =mysqli_query($connection,"INSERT INTO login(Email, Password) VALUES('$Email','$Password');"); 
            
                 echo "<script>window.location='login.php';</script>";
    
         
if (!$query && !$query1)
  {
  die('Error: ' . mysql_error());
  }
}



?>





<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="signup_style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    
    <script>
    
    var Password = document.getElementById("pwd")
  , Confirm = document.getElementById("cpwd");

function validatePassword(){
  if(Password.value != Confirm.value) {
    Confirm.setCustomValidity("Passwords Don't Match");
  } else {
    
      Confirm.setCustomValidity('');
  }
}

Password.onchange = validatePassword;
Confirm.onkeyup = validatePassword;
    
    
    
    </script>
    
<body>

<nav class="navbar navbar-default navbar-top-fixed">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><i class="fa fa-hand-peace-o"></i> Rayqube </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home </a></li>
        
       
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
			<li><a href="login.php">Login <i class="fa fa-user"></i></a></li>
			<li><a href="signup.php"> Sign Up  <i class="fa fa-user-plus"></i></a></li>
	</ul>		
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>



<div class="container">
    <div class="row">
        <div class="form_bg">
            <form method="post">
                 <h2 class="text-center">SignUp Page</h2>
                <br/>
                <div class="form-group">
                    <input type="name" name="Name" class="form-control" id="userid" placeholder="Name" autocomplete="off"  required>
                </div>
                <div class="form-group">
                    <input type="password" name="Password" class="form-control" id="pwd" minlength="5" maxlength="12" placeholder="Password" autocomplete="off"  required>
                </div>
                <div class="form-group">
                    <input type="password" name="Confirm" class="form-control" id="cpwd" minlength="5" maxlength="12"  placeholder="Confirm" autocomplete="off"   required>
                </div>
                <div class="form-group">
                    <input type="email" name="Email" class="form-control" id="pwd" placeholder="Email" autocomplete="off"  required>
                </div>
                <div class="form-group">
                    <input type="tel" name="Contact" class="form-control" pattern="[789][0-9]{9}"  id="userid" placeholder="Contact" autocomplete="off"  required>
                </div>
                <div class="form-group">
                    <input type="text" name="Nationality" class="form-control" id="pwd" placeholder="Nationality" autocomplete="off"  required>
                </div>
                 <div class="form-group">
                    
                     <select class="form-control" name="Roll" required>
            <option value="teacher">User</option>
            <option value="student">Admin</option>
            </select>
                </div>
                <div class="form-group">
                    <input type="checkbox" autocomplete="off" required > I agree.    
                </div>
                <br/>
                <div class="align-center">
                    <button type="submit" name="submit" class="btn btn-default" id="login">SignUp</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>