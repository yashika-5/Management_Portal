<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>field survey</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />


        <!-- C3 charts css -->
        <link rel="stylesheet"  href="../plugins/c3/c3.min.css"  type="text/css"  />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <script src="assets/js/modernizr.min.js"></script>

    </head>


    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <!--<a href="index.php" class="logo"><span>Code<span>Fox</span></span><i class="mdi mdi-layers"></i></a>-->
                    <!-- Image logo -->
                    <a href="index.php" class="logo">
                        <span>
                        <h3 class="streamlogo"><img src="sm.png" alt="" height="35"> Rayqube </h3>
                        </span>
                        <i>
                            <img src="sm.png" alt="" height="28">
                        </i>
						
                    </a>
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">

                        <!-- Navbar-left -->
                       

                        <!-- Right(Notification) -->
                        <ul class="nav navbar-nav navbar-right">
                           
                            <li>
                              
                                <ul class="dropdown-menu dropdown-menu-right dropdown-lg user-list notify-list">
                                    <li class="list-group notification-list m-b-0">
                                        <div class="slimscroll">
                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-diamond bg-primary"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-primary">A new order has been placed A new order has been placed</h5>
                                                    <p class="m-0">
                                                        There are new settings available
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>

                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-cog bg-warning"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-warning">New settings</h5>
                                                    <p class="m-0">
                                                        There are new settings available
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>

                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-bell-o bg-custom"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-custom">Updates</h5>
                                                    <p class="m-0">
                                                        There are <span class="text-primary font-600">2</span> new updates available
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>

                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-user-plus bg-danger"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-danger">New user registered</h5>
                                                    <p class="m-0">
                                                        You have 10 unread messages
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>

                                            <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-diamond bg-primary"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-primary">A new order has been placed A new order has been placed</h5>
                                                    <p class="m-0">
                                                        There are new settings available
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>

                                           <!-- list item-->
                                           <a href="javascript:void(0);" class="list-group-item">
                                              <div class="media">
                                                 <div class="media-left p-r-10">
                                                    <em class="fa fa-cog bg-warning"></em>
                                                 </div>
                                                 <div class="media-body">
                                                    <h5 class="media-heading text-warning">New settings</h5>
                                                    <p class="m-0">
                                                        There are new settings available
                                                    </p>
                                                 </div>
                                              </div>
                                           </a>
                                       </div>
                                    </li>
                                    <!-- end notification list -->
                                </ul>
                            </li>

                          
                                
                                    <a href="logout.php">    <button class="button" style="margin-top: 20px;">Logout</button></a>
                              

                                

                        </ul> <!-- end navbar-right -->

                    </div><!-- end container -->
                </div><!-- end navbar -->
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metisMenu nav" id="side-menu">
                            <li class="menu-title">Navigation</li>
                            <li>
                                <a href="index.php"><i class="fi-air-play"></i> <span> Dashboard </span></a>
                            </li>
					       <li>
                                <a href="mainform.php"><i class="fi-air-play"></i> <span> ProjectDetails </span></a>
                            </li>
					
						
				
	
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->
