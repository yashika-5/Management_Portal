<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lato:400,700' ">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="index_style.css">
	
</head>
    
    <style>
    
    .pink{
			background: url("slide4.jpg");
			background-size: cover;
			background-position: center;
			font-family: Lato;
		}
         h1{
			color: purple;
			font-size: 5em;
			font-weight: 700;


		}
		hr{
			width: 400px;
			border-top: 1px solid #f8f8f8;
			border-bottom: 1px solid rgba(0,0,0,0.2);
		}

		#content{
			padding-top: 25%;
			padding-bottom: 10%;
			text-align: center;

			text-shadow: 0px 4px 3px rgba(0,0,0,0.4),0px 8px 13px rgba(0,0,0.1), 0px 18px 13px rgba(0,0,0,0.1); 
		}
		html{
			height: 100%;
		}
		
		 h3{
			color: white;
			font-weight: 500;
		}
		.footer{
			width: 100%;
			
			background:  #2c3e50;
			text-align: center;
			font-size: 15px;
			color: black;
			margin-top: 10%;
			padding-bottom: 7px;

		}
		#aa{
			font-size: 20px;
    text-align: center;
    font-family: 'Dancing Script',cursive;
    word-spacing: 3px;
		}
        body{
            background-color: #333;
        }
    </style>
<body>

	<nav class="navbar navbar-default navbar-top-fixed">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><i class="fa fa-hand-peace-o"></i> Rayqube</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home </a></li>
        
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
			<li><a href="login.php">Login <i class="fa fa-user"></i></a></li>
			<li><a href="signup.php"> Sign Up  <i class="fa fa-user-plus"></i></a></li>
	</ul>		
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>
    
    <div class="container">
      <div class="jumbotron" style="font-size: 20px;text-align:center;">Rayqube</div>
    </div>
    
    <div class="container" >
       <img src="slide4.jpg" style="margin-left:120px;">
            
    </div>
    
    <div class="container-fluid">
      <div class="jumbotron" style="font-size: 10px;text-align:center;margin-top: 40px;">Copyrights are reserved.2018</div>
    </div>

   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    </body>
</html>