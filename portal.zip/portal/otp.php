<?php
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <title>Enter Otp</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/custom2.css" type="text/css ">
 
 
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="../plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="css/login.css" rel="stylesheet" type="text/css" />
        <script src="assets/js/modernizr.min.js"></script>


</head>
<body style="background-color: skyblue;">

<section>
    

			<div class="container">
                <div class="row">
                    <div class="col-sm-12">
					    <div class="wrapper-page" class="form">
							<div class="account-pages">
                                <div class="account-box">
                                    <div class="account-logo-box">
                                        <h2 class="text-uppercase text-center">
                                            <a href="#" class="text-success">
                                                <span><img src="sm.png" alt="" height="180"></span>
                                            </a>
                                        </h2>
                                        
                                       
                                    </div>
									<div class="account-content">
										<form class="form-horizontal" action="#">
								 
											<div class="form-group m-b-20">
												<div class="col-xs-4"></div>
												<div class="col-xs-4">
												<label for="emailaddress" class="otp">Enter Your Otp:</label>
												<input class="form-control"  class="otpmu" type="" required="" placeholder="6-digit otp">
												</div>
												<div class="col-xs-4"></div>
											</div>
											<div class="form-group text-center m-t-10">
                                                <div class="col-xs-4"></div>
												<div class="col-xs-4">
                                                    <a href="changepwd.php"><button class="btn btn-sm btn-block btn-primary waves-effect waves-light" type="submit" class="buttonw">Confirm</button></a>
                                                </div>
												<div class="col-xs-4">
                                            </div>
										</form>
										<div class="clearfix"></div>
										<div class="row m-t-40">
                                            <div class="col-sm-12 text-center">
                                                <p class="text-muted">Back to <a href="login.php" class="text-dark m-l-5"><b>Sign In</b></a></p>
                                            </div>
                                        </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>			
				</div>						
			</div>
</section>



<script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="../plugins/bootstrap-select/js/bootstrap-select.min.js" type="text/javascript"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

</body>
</html>
